# ML Internship Project

This repository contains my completed internship project, which consists of three main tasks related to natural language processing and text-to-image generation using transformers.

## Project Structure

```
internship_project/
├── task1_tokenization/
├── task2_text2image_preprocessing/
└── task3_fine_tuning/
```

## Tasks Overview

### Task 1: Tokenization & Encoding with BERT
- Implementation of text tokenization using BERT
- Demonstration of encoding text into numerical representations
- Visualization of token embeddings

### Task 2: Preprocessing for Text-to-Image with CLIP Tokenizer
- Using CLIP tokenizer for text-to-image preprocessing
- Encoding image descriptions for use with Stable Diffusion
- Comparing and visualizing text embeddings

### Task 3: Fine-Tuning Text-to-Image Model on Custom Dataset
- Fine-tuning Stable Diffusion using DreamBooth technique
- Training on a small custom dataset
- Generating and evaluating custom images

## Requirements

Each task folder contains its own `requirements.txt` file with the necessary dependencies.

## Model Files

The fine-tuned model from Task 3 is available at the following Google Drive link due to its large size:
[Fine-tuned Stable Diffusion Model](https://drive.google.com/drive/folders/your-folder-id)
                    